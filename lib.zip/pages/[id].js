/*[id].js*/
import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Image from 'next/image';
import {useRouter} from 'next/router';
import data from '../db/data.json';
import styles from '../src/app/globals.css';
import { getCart, addToCart, removeFromCart} from '../components/Cart';
import SimilarProducts from '../components/similar';

function Product({ product }) {
  const products = data.data;
  const { id, title, description, price, currency, image } = product;
  const [cartItems, setCartItems] = useState([]);
  
  useEffect(() => {
    const cartItems = getCart();
    setCartItems(cartItems);
  }, []);
  
  const router = useRouter();
  const isProductInCart = cartItems.some((item) => item.id === id);
  const GRABBER = isProductInCart ? 'REMOVE FROM CART': 'GRAB';
  const handleAddToCart = () => {
    if(isProductInCart) {
      removeFromCart(product);
    } else {
      addToCart(product);
    }
    router.push('/cart'); 
  };  
  const handleRemoveFromCart = () => {
    removeFromCart(product);
  };
  const [satoshis, setSatoshis] = useState(null);

  useEffect(() => {
    // Fetch the Bitcoin price from Coingecko API
    fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd')
      .then((response) => response.json())
      .then((data) => {
        const bitcoinPrice = data.bitcoin.usd; // Get the Bitcoin price in USD from the API response
        const satoshisValue = Math.floor((price / bitcoinPrice) * 100000000); // Convert price to satoshis
        setSatoshis(satoshisValue);
      })
      .catch((error) => {
        console.log('Error fetching Bitcoin price:', error);
      });
  }, [price, satoshis]);

  return (
    <div className="container">
      <Head>
        <title>{title}</title>
      </Head>
      <header className="header">
        <Link href="/">
          <h1 className="head">cry</h1>
        </Link>
        <div className="searchForm">
          <input
            type="text"
            placeholder="Search for tools"
            className="searchInput"
          />
          {/* Add search button or submit functionality as needed */}
        </div>
        <div className="cartCount">{cartItems.length}</div>
        <Link href="/cart"><div className="cartIcon">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 22" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" shapeRendering="geometricPrecision" className="h-6 transition-all ease-in-out hover:scale-110 hover:text-gray-500 dark:hover:text-gray-300"><path d="M4 1L1 5V19C1 19.5304 1.21071 20.0391 1.58579 20.4142C1.96086 20.7893 2.46957 21 3 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V5L16 1H4Z"></path><path d="M1 5H19"></path><path d="M14 9C14 10.0609 13.5786 11.0783 12.8284 11.8284C12.0783 12.5786 11.0609 13 10 13C8.93913 13 7.92172 12.5786 7.17157 11.8284C6.42143 11.0783 6 10.0609 6 9"></path></svg>
        </div></Link>
      </header>
      <main className="productPage">
        <div className="grid-container">
          <div className="image-container">
            <Image width={500} height={500} src={image} alt={title} />
          </div>
          <div className="details-container">
            <h1 className="title">{title}</h1>
            <p>{description}</p>
            <p>{satoshis !== null ? satoshis : price} SAT / {price} {currency} </p>
            <button
              className={isProductInCart ? 'whiteButton' : 'buyButton'}
              onClick={handleAddToCart}
            >{GRABBER}
            </button>
          </div>
        </div>
        <SimilarProducts currentProduct={product} />
      </main>
    </div>
  );
}

export async function getStaticPaths() {
  const paths = data.data.map((product) => ({
    params: { id: product.id },
  }));

  return {
    paths,
    fallback: false,
  };
}

export async function getStaticProps({ params }) {
  const { id } = params;
  const product = data.data.find((product) => product.id === id);
  if (!product) {
    return {
      props: {},
    };
  }

  return {
    props: {
      product,
    },
  };
}

export default Product;
