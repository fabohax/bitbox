/* cart.js */
import React, { useState, useEffect } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Image from 'next/image';
import { useRouter } from 'next/router';
import { getCart, removeAllFromCart } from '../components/Cart';
import CheckoutPopup from '../components/checkoutPopup';
import styles from '../src/app/globals.css';

function Cart() {
  const router = useRouter();
  const [showPopup, setShowPopup] = useState(false);
  const [cartItems, setCartItems] = useState([]);
  
  useEffect(() => {
    const cartItems = getCart();
    setCartItems(cartItems);
  }, []);

  const handleCheckoutClick = () => {
    setShowPopup(true);
  };

  const handleClearCart = () => {
    removeAllFromCart();
    router.push('/cart');
  };

  const totalPrice = cartItems.reduce((total, item) => total + item.price, 0);

  return (
    <div className="container">
      <Head>
        <title>CRY Store</title>
      </Head>
      <header className="header">
        <Link href="/">
          <h1 className="head">cry</h1>
        </Link>
        <div className="searchForm">
          <input type="text" placeholder="Search for Tools" className="searchInput" />
        </div>
        <Link href="/cart">
          <div className="cartIcon">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 22"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              shapeRendering="geometricPrecision"
              className="h-6 transition-all ease-in-out hover:scale-110 hover:text-gray-500 dark:hover:text-gray-300"
            >
              <path d="M4 1L1 5V19C1 19.5304 1.21071 20.0391 1.58579 20.4142C1.96086 20.7893 2.46957 21 3 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V5L16 1H4Z"></path>
              <path d="M1 5H19"></path>
              <path d="M14 9C14 10.0609 13.5786 11.0783 12.8284 11.8284C12.0783 12.5786 11.0609 13 10 13C8.93913 13 7.92172 12.5786 7.17157 11.8284C6.42143 11.0783 6 10.0609 6 9"></path>
            </svg>
          </div>
        </Link>
      </header>
      {cartItems && cartItems.length > 0 ? (
        <div className="cartCheck">
          {cartItems.length} item{cartItems.length === 1 ?('') : ('s')} for ${totalPrice}{' '}
          <Link href="#" onClick={handleCheckoutClick}>
            Checkout Now
          </Link>
        </div>
      ) : (
        <div className="noItems">No items in Cart</div>
      )}
      <main className="grid">
        {/* Render cart items */}
        {cartItems.map((item) => (
          <div className="cartItem" key={item.id}>
            <div className="squareItem">
              <Link href={`/${item.id}`} passHref>
                <Image width={350} height={350} src={item.image} alt={item.title} />
              </Link>
            </div>
            <p>{item.title}</p>
            <p>{item.price}$</p>
          </div>
        ))}
      </main>
      {cartItems && cartItems.length > 0 && (
        <Link href="#" onClick={handleClearCart} className="clearCart">
          Clear Cart
        </Link>
      )}
      {showPopup && <CheckoutPopup />}
    </div>
  );
}

export default Cart;
