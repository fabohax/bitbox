import React from 'react';
import Head from 'next/head';

// Import the CSS files for the Google Fonts
import 'typeface-roboto';
import 'typeface-roboto-mono';


function MyApp({ Component, pageProps }) {
    return (
      <>
        <Head>
          {/* Add any necessary meta tags */}
        </Head>
        <Component {...pageProps} />
      </>
    );
  }
  
  export default MyApp;
  